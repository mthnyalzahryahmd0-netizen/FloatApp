The Gradle wrapper properties are pinned to Gradle 8.13.
The official gradle-wrapper.jar is intentionally not vendored because this build environment cannot download external binaries.
Codemagic's workflow uses its preinstalled Gradle command directly, so the cloud build does not depend on the wrapper JAR.
