# FloatApp does not require custom ProGuard rules for the starter build.
