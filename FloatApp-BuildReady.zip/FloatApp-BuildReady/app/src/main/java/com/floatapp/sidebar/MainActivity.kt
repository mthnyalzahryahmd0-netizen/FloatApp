package com.floatapp.sidebar

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.nativead.AdLoader
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.UserMessagingPlatform

class MainActivity : AppCompatActivity() {
    private lateinit var enabledSwitch: Switch
    private lateinit var status: TextView
    private lateinit var billing: BillingManager
    private lateinit var banner: AdView
    private var nativeAd: NativeAd? = null
    private val langs = listOf("system", "ar", "en", "es", "fr", "de", "pt", "tr", "id", "hi", "ru", "ja", "ko", "zh")
    private val langNames by lazy { listOf(getString(R.string.system_default), getString(R.string.language_ar), getString(R.string.language_en), getString(R.string.language_es), getString(R.string.language_fr), getString(R.string.language_de), getString(R.string.language_pt), getString(R.string.language_tr), getString(R.string.language_id), getString(R.string.language_hi), getString(R.string.language_ru), getString(R.string.language_ja), getString(R.string.language_ko), getString(R.string.language_zh)) }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi(); billing = BillingManager(this) { updateAds() }; billing.connect(); requestConsentAndLoadAds() }
    override fun onResume() { super.onResume(); if (::enabledSwitch.isInitialized) { enabledSwitch.isChecked = AppPrefs.enabled(this); refreshStatus() } }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 12); layoutDirection = View.LAYOUT_DIRECTION_LOCALE }
        val scroll = ScrollView(this).apply { addView(root) }
        val title = TextView(this).apply { text = getString(R.string.title); textSize = 30f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
        val sub = TextView(this).apply { text = getString(R.string.subtitle); textSize = 15f; setPadding(0, 4, 0, 20) }
        root.addView(title); root.addView(sub)

        enabledSwitch = Switch(this).apply { text = getString(R.string.enable_sidebar); textSize = 17f; isChecked = AppPrefs.enabled(this@MainActivity); setOnCheckedChangeListener { _, checked -> toggleSidebar(checked) } }
        root.addView(enabledSwitch)
        status = TextView(this).apply { setPadding(0, 4, 0, 16) }; root.addView(status); refreshStatus()

        val permission = Button(this).apply { text = getString(R.string.open_overlay_settings); setOnClickListener { requestOverlayPermission() } }
        root.addView(permission)
        root.addView(section(getString(R.string.favorites)))
        val favoritesButton = Button(this).apply { text = getString(R.string.select_apps); setOnClickListener { startActivity(Intent(this@MainActivity, AppPickerActivity::class.java)) } }
        root.addView(favoritesButton)

        root.addView(section(getString(R.string.language)))
        val languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langNames)
        val currentTag = AppCompatDelegate.getApplicationLocales().toLanguageTags().ifBlank { "system" }
        languageSpinner.setSelection(langs.indexOf(currentTag).takeIf { it >= 0 } ?: 0)
        languageSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { val tag = langs[position]; if (tag != currentTag) AppCompatDelegate.setApplicationLocales(if (tag == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag)) }
        }
        root.addView(languageSpinner)

        root.addView(section(getString(R.string.appearance)))
        val styleSpinner = Spinner(this)
        styleSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf(getString(R.string.style_side), getString(R.string.style_button)))
        styleSpinner.setSelection(if (AppPrefs.style(this) == "button") 1 else 0)
        styleSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { AppPrefs.setStyle(this@MainActivity, if (position == 1) "button" else "side"); if (AppPrefs.enabled(this@MainActivity)) restartService() }
        }
        root.addView(styleSpinner)

        root.addView(section(getString(R.string.remove_ads)))
        root.addView(TextView(this).apply { text = getString(R.string.remove_ads_desc); setPadding(0,0,0,8) })
        val buy = Button(this).apply { text = getString(R.string.buy_remove_ads); setOnClickListener { billing.buy(this@MainActivity) } }
        val restore = Button(this).apply { text = getString(R.string.restore_purchase); setOnClickListener { billing.restore() } }
        root.addView(buy); root.addView(restore)
        root.addView(TextView(this).apply { text = getString(R.string.ads_note); textSize = 12f; setPadding(0, 4, 0, 16) })

        val adContainer = FrameLayout(this).apply { minimumHeight = 120 }
        root.addView(adContainer)
        setContentView(scroll)
        banner = AdView(this).apply { adUnitId = "ca-app-pub-3940256099942544/6300978111"; setAdSize(adSize()); visibility = View.GONE }
        root.addView(banner)
        updateAds()
    }

    private fun section(text: String) = TextView(this).apply { this.text = text; textSize = 20f; setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, 24, 0, 10) }
    private fun adSize(): AdSize { val dm = resources.displayMetrics; val width = (dm.widthPixels / dm.density).toInt(); return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, width) }
    private fun loadNativeAd(container: FrameLayout) {
        if (AppPrefs.adsRemoved(this)) return
        val loader = AdLoader.Builder(this, "ca-app-pub-3940256099942544/2247696110").forNativeAd { ad -> nativeAd?.destroy(); nativeAd = ad; container.removeAllViews(); val adView = NativeAdView(this); val title = TextView(this).apply { textSize = 16f; setTypeface(typeface, android.graphics.Typeface.BOLD) }; val body = TextView(this).apply { textSize = 13f }; val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,16,16,16); addView(TextView(this@MainActivity).apply { text=getString(R.string.native_ad); textSize=11f }); addView(title); addView(body) }; title.text = ad.headline ?: ""; body.text = ad.body ?: ""; adView.addView(layout); adView.headlineView = title; adView.bodyView = body; adView.setNativeAd(ad); container.addView(adView, FrameLayout.LayoutParams(-1,-2)) }.withNativeAdOptions(NativeAdOptions.Builder().build()).build()
        loader.loadAd(AdRequest.Builder().build())
    }
    private fun requestConsentAndLoadAds() {
        val consentInfo = UserMessagingPlatform.getConsentInformation(this)
        consentInfo.requestConsentInfoUpdate(this, com.google.android.ump.ConsentRequestParameters.Builder().build(), {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) {
                if (consentInfo.canRequestAds() && !AppPrefs.adsRemoved(this)) {
                    MobileAds.initialize(this)
                    val container = findNativeContainer()
                    if (container != null) loadNativeAd(container)
                    if (::banner.isInitialized) { banner.visibility = View.VISIBLE; banner.loadAd(AdRequest.Builder().build()) }
                }
            }
        }, {
            if (consentInfo.canRequestAds() && !AppPrefs.adsRemoved(this)) {
                MobileAds.initialize(this)
                val container = findNativeContainer()
                if (container != null) loadNativeAd(container)
                if (::banner.isInitialized) { banner.visibility = View.VISIBLE; banner.loadAd(AdRequest.Builder().build()) }
            }
        })
    }
    private fun findNativeContainer(): FrameLayout? {
        val scroll = (findViewById<ViewGroup>(android.R.id.content)?.getChildAt(0) as? ScrollView) ?: return null
        val root = scroll.getChildAt(0) as? ViewGroup ?: return null
        for (i in 0 until root.childCount) if (root.getChildAt(i) is FrameLayout) return root.getChildAt(i) as FrameLayout
        return null
    }
    private fun updateAds() { if (!::banner.isInitialized) return; val removed = AppPrefs.adsRemoved(this); banner.visibility = if (removed) View.GONE else View.VISIBLE }
    private fun refreshStatus() { status.text = if (AppPrefs.enabled(this)) getString(R.string.sidebar_enabled) else getString(R.string.sidebar_disabled) }
    private fun toggleSidebar(enable: Boolean) { if (enable && !Settings.canDrawOverlays(this)) { enabledSwitch.isChecked = false; requestOverlayPermission(); return }; AppPrefs.setEnabled(this, enable); if (enable) startService() else stopService(); refreshStatus() }
    private fun requestOverlayPermission() { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
    private fun startService() { if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20); val i=Intent(this,FloatingSidebarService::class.java); if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i) }
    private fun stopService() { stopService(Intent(this, FloatingSidebarService::class.java)) }
    private fun restartService() { stopService(); startService() }
    override fun onDestroy() { nativeAd?.destroy(); if (::banner.isInitialized) banner.destroy(); super.onDestroy() }
}
