package com.floatapp.sidebar

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo

object LauncherApps {
    data class Item(val packageName: String, val label: String, val icon: android.graphics.drawable.Drawable)
    fun load(context: Context): List<Item> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { r: ResolveInfo -> Item(r.activityInfo.packageName, r.loadLabel(pm).toString(), r.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }
}
