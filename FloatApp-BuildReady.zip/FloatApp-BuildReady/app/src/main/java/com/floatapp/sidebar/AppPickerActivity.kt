package com.floatapp.sidebar

import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AppPickerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,20,16,8) }
        root.addView(TextView(this).apply { text=getString(R.string.choose_apps); textSize=22f; setPadding(8,0,8,12) })
        val list = RecyclerView(this).apply { layoutManager=LinearLayoutManager(this@AppPickerActivity) }
        val items = LauncherApps.load(this)
        val selected = AppPrefs.favorites(this).toMutableSet()
        if (selected.isEmpty()) selected.addAll(items.take(6).map { it.packageName })
        list.adapter = Adapter(items, selected)
        root.addView(list, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(Button(this).apply { text=getString(R.string.save); setOnClickListener { AppPrefs.setFavorites(this@AppPickerActivity, selected); if(AppPrefs.enabled(this@AppPickerActivity)){ stopService(android.content.Intent(this@AppPickerActivity,FloatingSidebarService::class.java)); val i=android.content.Intent(this@AppPickerActivity,FloatingSidebarService::class.java); if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i) }; Toast.makeText(this@AppPickerActivity,getString(R.string.saved),Toast.LENGTH_SHORT).show(); finish() } })
        if(items.isEmpty()) root.addView(TextView(this).apply{text=getString(R.string.no_apps)})
        setContentView(root)
    }
    private class Adapter(private val items: List<LauncherApps.Item>, private val selected: MutableSet<String>) : RecyclerView.Adapter<Holder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder { val row=LinearLayout(parent.context).apply{orientation=LinearLayout.HORIZONTAL;gravity=android.view.Gravity.CENTER_VERTICAL;setPadding(8,10,8,10)}; val icon=ImageView(parent.context); row.addView(icon,80,80); val text=TextView(parent.context).apply{textSize=16f;setPadding(16,0,0,0)}; row.addView(text,LinearLayout.LayoutParams(0,80,1f)); val check=CheckBox(parent.context); row.addView(check); return Holder(row,icon,text,check) }
        override fun onBindViewHolder(h: Holder, pos: Int){ val item=items[pos]; h.icon.setImageDrawable(item.icon); h.text.text=item.label; h.check.isChecked=selected.contains(item.packageName); h.row.setOnClickListener{val now=!selected.contains(item.packageName);if(now)selected.add(item.packageName)else selected.remove(item.packageName);h.check.isChecked=now}; h.check.setOnClickListener{if(h.check.isChecked)selected.add(item.packageName)else selected.remove(item.packageName)} }
        override fun getItemCount()=items.size
    }
    private class Holder(val row:LinearLayout,val icon:ImageView,val text:TextView,val check:CheckBox):RecyclerView.ViewHolder(row)
}
