package com.floatapp.sidebar

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingSidebarService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private val channelId = "floatapp_sidebar"
    override fun onCreate() { super.onCreate(); createChannel(); startForeground(1001, notification()); wm=getSystemService(WINDOW_SERVICE) as WindowManager; if(Settings.canDrawOverlays(this)) showOverlay() else stopSelf() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if(overlay==null && Settings.canDrawOverlays(this)) showOverlay(); return START_STICKY }
    private fun createChannel(){ val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager; if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(channelId,"FloatApp",NotificationManager.IMPORTANCE_LOW)) }
    private fun notification(): Notification { val pi=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); return NotificationCompat.Builder(this,channelId).setSmallIcon(com.floatapp.sidebar.R.drawable.ic_floatapp).setContentTitle(getString(R.string.app_name)).setContentText(getString(R.string.sidebar_enabled)).setContentIntent(pi).setOngoing(true).build() }
    private fun showOverlay(){
        val style=AppPrefs.style(this); val lp=WindowManager.LayoutParams(if(style=="button") 60 else 72, WindowManager.LayoutParams.WRAP_CONTENT, if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity=Gravity.END or Gravity.CENTER_VERTICAL; lp.x=8
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(6,10,6,10);background=bg(0xEE1C1B1F.toInt(),28f)}
        val packages=AppPrefs.favorites(this); val apps=LauncherApps.load(this); val selected=if(packages.isEmpty())apps.take(6) else apps.filter{packages.contains(it.packageName)}
        selected.take(8).forEach{item-> val b=ImageButton(this).apply{setImageDrawable(item.icon);contentDescription=item.label;background=bg(Color.TRANSPARENT,18f);setPadding(8,8,8,8);setOnClickListener{launch(item.packageName)}};box.addView(b,LinearLayout.LayoutParams(56,56).apply{bottomMargin=4}) }
        val gear=ImageButton(this).apply{setImageResource(android.R.drawable.ic_menu_preferences);contentDescription=getString(R.string.settings);background=bg(0x3325FFFFFF,18f);setOnClickListener{startActivity(Intent(this@FloatingSidebarService,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}}
        box.addView(gear,LinearLayout.LayoutParams(56,56))
        overlay=if(style=="button") makeDraggable(box,lp) else box
        wm.addView(overlay,lp)
    }
    private fun makeDraggable(v:View,lp:WindowManager.LayoutParams):View{ var downX=0f;var downY=0f;var startX=0;var startY=0;v.setOnTouchListener{_,e->when(e.action){MotionEvent.ACTION_DOWN->{downX=e.rawX;downY=e.rawY;startX=lp.x;startY=lp.y;true};MotionEvent.ACTION_MOVE->{lp.x=startX-(e.rawX-downX).toInt();lp.y=startY+(e.rawY-downY).toInt();wm.updateViewLayout(v,lp);true};else->false}};return v }
    private fun launch(pkg:String){ try{val i=packageManager.getLaunchIntentForPackage(pkg); if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);startActivity(i)}}catch(_:Exception){} }
    private fun bg(color:Int,r:Float)=GradientDrawable().apply{setColor(color);cornerRadius=r}
    override fun onDestroy(){overlay?.let{try{wm.removeView(it)}catch(_:Exception){}};overlay=null;super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
