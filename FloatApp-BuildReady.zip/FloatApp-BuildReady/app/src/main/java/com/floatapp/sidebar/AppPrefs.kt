package com.floatapp.sidebar

import android.content.Context

object AppPrefs {
    private const val FILE = "floatapp_prefs"
    private const val ENABLED = "enabled"
    private const val STYLE = "style"
    private const val ADS_REMOVED = "ads_removed"
    private const val FAVORITES = "favorites"
    fun prefs(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun enabled(c: Context) = prefs(c).getBoolean(ENABLED, false)
    fun setEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(ENABLED, v).apply()
    fun style(c: Context) = prefs(c).getString(STYLE, "side") ?: "side"
    fun setStyle(c: Context, v: String) = prefs(c).edit().putString(STYLE, v).apply()
    fun adsRemoved(c: Context) = prefs(c).getBoolean(ADS_REMOVED, false)
    fun setAdsRemoved(c: Context, v: Boolean) = prefs(c).edit().putBoolean(ADS_REMOVED, v).apply()
    fun favorites(c: Context): Set<String> = prefs(c).getStringSet(FAVORITES, emptySet()) ?: emptySet()
    fun setFavorites(c: Context, set: Set<String>) = prefs(c).edit().putStringSet(FAVORITES, set).apply()
}
