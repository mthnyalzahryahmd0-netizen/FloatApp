package com.floatapp.sidebar

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*

class BillingManager(private val context: Context, private val onAdsRemoved: () -> Unit) : PurchasesUpdatedListener {
    companion object { const val PRODUCT_ID = "remove_ads" }
    private val billingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .enableAutoServiceReconnection()
        .build()
    private var productDetails: ProductDetails? = null

    fun connect() {
        if (billingClient.isReady) { queryProduct(); return }
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) { if (result.responseCode == BillingClient.BillingResponseCode.OK) queryProduct() }
            override fun onBillingServiceDisconnected() {}
        })
    }
    private fun queryProduct() {
        val params = QueryProductDetailsParams.newBuilder().setProductList(
            listOf(QueryProductDetailsParams.Product.newBuilder().setProductId(PRODUCT_ID).setProductType(BillingClient.ProductType.INAPP).build())
        ).build()
        billingClient.queryProductDetailsAsync(params) { result, details ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) productDetails = details.productDetailsList.firstOrNull()
            restore()
        }
    }
    fun buy(activity: Activity) {
        val details = productDetails ?: run { connect(); return }
        val offer = details.oneTimePurchaseOfferDetails ?: return
        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(details).setOfferToken(offer.offerToken).build()
        billingClient.launchBillingFlow(activity, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(productParams)).build())
    }
    fun restore() {
        if (!billingClient.isReady) return
        billingClient.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()) { _, purchases ->
            if (purchases.any { it.products.contains(PRODUCT_ID) && it.purchaseState == Purchase.PurchaseState.PURCHASED }) {
                purchases.filter { it.products.contains(PRODUCT_ID) && !it.isAcknowledged }.forEach { acknowledge(it) }
                AppPrefs.setAdsRemoved(context, true); onAdsRemoved()
            }
        }
    }
    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) purchases.forEach { if (it.products.contains(PRODUCT_ID) && it.purchaseState == Purchase.PurchaseState.PURCHASED) acknowledge(it) }
    }
    private fun acknowledge(purchase: Purchase) {
        if (purchase.isAcknowledged) { AppPrefs.setAdsRemoved(context, true); onAdsRemoved(); return }
        billingClient.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()) { result ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) { AppPrefs.setAdsRemoved(context, true); onAdsRemoved() }
        }
    }
}
