package com.floatapp.sidebar

import android.app.Application

class FloatApp : Application()
