# FloatApp — build in the cloud (no Android Studio required)

This project is configured for Codemagic. The included workflow builds an installable, debug-signed APK named `FloatApp.apk`.

## 1. Create a GitHub repository

1. Sign in to GitHub and create a new repository, e.g. `FloatApp`.
2. Extract this ZIP on your phone/computer.
3. Upload the **contents of the `FloatApp` folder** to the repository root. `codemagic.yaml` must be in the repository root.

## 2. Connect GitHub to Codemagic

1. Open https://codemagic.io/ and create/sign in to an account.
2. Add a new application and connect your GitHub account.
3. Select the `FloatApp` repository.
4. Choose Android/native Android if prompted.
5. Select the branch containing `codemagic.yaml` and use the YAML configuration.
6. Start the `android-apk` workflow.

## 3. Download the APK

When the build succeeds, open the build result and download the artifact:

`FloatApp.apk`

Copy it to your Android phone and open it to install. Android may ask you to allow installation from that source.

## Important

- This workflow intentionally builds `assembleDebug`. Debug APKs are signed with the Android debug key and are directly installable for testing.
- For Google Play production, create a private release keystore and configure Codemagic Android signing instead of distributing the debug APK.
- The project uses Google's official test AdMob IDs. Replace them before production release.
- The one-time product ID is `remove_ads`.
- The floating sidebar itself contains no AdMob ads; ads are shown only inside FloatApp's own UI.
